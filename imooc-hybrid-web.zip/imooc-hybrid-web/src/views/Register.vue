<template>
  <div class="register-page">
    <navigation-bar :pageName="'注册'" @onLeftClick="onBackClick"></navigation-bar>
    <!-- 内容区 -->
    <div class="register-page-content">
      <!-- 用户名 -->
      <div class="input-container">
        <input v-model="username" type="text" placeholder="用户名" />
      </div>
      <!-- 密码 -->
      <div class="input-container">
        <input v-model="password" type="password" placeholder="密码" />
      </div>
      <!-- 确认密码 -->
      <div class="input-container">
        <input v-model="confirmPassword" type="password" placeholder="确认密码" />
      </div>
      <div class="register-page-content-register page-commit" @click="onRegisterClick">注册</div>
    </div>
  </div>
</template>

<script>
import NavigationBar from "@c/currency/NavigationBar";
import md5 from "@js/md5.min.js";
export default {
  name: "register",
  components: {
    NavigationBar
  },
  data() {
    return {
      username: "",
      password: "",
      confirmPassword: "",
      md5Password: ""
    };
  },
  methods: {
    /**
     * 后退事件
     */
    onBackClick() {
      this.$router.go(-1);
    },
    /**
     * 注册按钮点击事件
     */
    // onRegisterClick() {
    //   //验证输入的合法性
    //   /**
    //    *  用户满意输入用户名,或者用户没有输入密码,或者用户输入的密码和确认密码不相同
    //    */
    //   if (this.username.length === 0) {
    //     alert("请完善用户名");
    //     return;
    //   }
    //   if (this.password.length === 0 || this.password != this.confirmPassword) {
    //     alert("请完善用户名");
    //     return;
    //   }
    //   //与原生交互,保存用户输入的用户名和密码

    //   //对用户输入的密码进行 md5 加密
    //   this.md5Password = md5(this.password);
    //   //判断当前的项目是运行在 Android 设备还是 IOS 设备中
    //   if (window.androidJBridge) {
    //     //window 下 android 注入的对象 (androidJSBridge),则表示当前项目在安卓对象中
    //     this.onRegisterToAndroid();
    //   } else if (window.kebkit) {
    //     //window 下存在 webkit,表现当前项目在IOS 设备中运行
    //      this.onRegisterToIos();
    //   }
    // },
    // /**
    //  *  调用 android 注册接口
    //  */
    // onRegisterToAndroid() {
    //   //创建json字符串 Android 只能接收基本数据类型
    //   let userJson = JSON.stringify({
    //     username: this.username,
    //     password: this.md5Password
    //   });
    //   // 调用android注册方法,接收他的返回值
    //   let result = window.androidJBridge.register(userJson);
    //   //对返回值进行处理
    //   this.onRegisterCallback(result);
    // },
    // /**
    //  * 调用 IOS 注册接口
    //  */
    // onRegisterToIOS() {
    //   //IOS 可以直接接收对象类型参数
    //   let userObj = {
    //     username: this.username,
    //     paddword: this.md5Password
    //   };
    //   /**
    //    * IOS 不能直接返回返回值.所以IOS 操作完成之后会回调对应的回调方法。
    //    * 同时原生调用 JS 的方法只能调用绑定到 window对象中的方法。
    //    * 所以我们需要把 IOS 操作完成之后的回调方法 (registerCallback)绑定到window对象下
    //    */
    //   window.onRegisterCallback = this.onRegisterCallback;
    //   //调用 IOS 注册方法
    //   window.webkit.messageHandlers.register.postMessage(userObj);
    // },
    // /**
    //  * 用来注册Native 注册接口返回值
    //  */
    // onRegisterCallback(result) {
    //   if (result) {
    //     alert("注册成功");
    //   } else {
    //     alert("注册失败,请重试!");
    //   }
    // }
  }
};
</script>

<style lang="scss" scoped>
@import "@css/style";

.register-page {
  position: absolute;
  width: 100%;
  height: 100%;
  background-color: white;
  &-content {
    width: 100%;
    height: 100%;
    &-register {
      margin-top: 40%;
    }
  }
}
</style>