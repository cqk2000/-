<template>
  <div class="login-page">
    <navigation-bar :pageName="'登录'" @onLeftClick="onBackClick"></navigation-bar>
    <!-- 内容区域 -->
    <div class="login-page-content">
      <div class="input-container">
        <input v-model="username" type="text" placeholder="用户名" />
      </div>
      <div class="input-container">
        <input v-model="password" type="password" placeholder="密码" />
      </div>
      <div class="login-page-content-login page-commit" @click="onLoginClick">登录</div>
      <a class="login-page-content-register" @click="onToRegister">注册新用户</a>
    </div>
  </div>
</template>

<script>
import NavigationBar from "@c/currency/NavigationBar";
import md5 from "@js/md5.min.js";

export default {
  name: "login",
  components: {
    NavigationBar
  },
  data() {
    return {
      //用户名
      username: "",
      //密码
      password: "",
      //md5 加密密码
      md5Password: ""
    };
  },
  methods: {
    //后退事件
    onBackClick() {
      this.$router.go(-1);
      console.log(1111);
    },
    // 登录按钮点击事件
  //   onLoginClick() {
  //     //验证用户输入的合法性
  //     /**
  //      * 如果用户没有输入用户名或密码的话,那么就直接 return 方法
  //      */
  //     if (this.username.length === 0 || this.password.length === 0) {
  //       alert("用户名或密码未输入");
  //       return;
  //     }
  //     //与原生交互,验证用户的输入的用户名和密码
  //     //对用户输入的密码 进行 MD5 加密

  //     // 判断当前项目是运行在Android 设备还是ios设备中
  //     this.md5Password = md5(this.password);
  //     if (window.androidJSBridge) {
  //       //window 下存在 android 注入的对象(androidJSBridge),则表示当前项目在安卓对象中;
  //       this.onLoginToAndroid();
  //     } else if (window.webkit) {
  //       //window 下存在 webkit,表示当前项目在ios 设备中运行
  //       this.onLoginToIOS();
  //     }
  //   },
  //   /**
  //    *  调用 android 登录验证
  //    */
  //   onLoginToAndroid() {
  //     // 创建json 字符串
  //     let userJson = JSON.stringify({
  //       username: this.username,
  //       password: this.md5Password
  //     });
  //     //调用 android 登录接口
  //     let result = window.androidJSBridge.login(userJson);
  //     //对android 的返回值 进行处理
  //     this.onLoginCallback(result);
  //   },
  //   /**
  //    * 调用IOS 登录验证
  //    */
  //   onLoginToIOS() {
  //     //创建 传输对象
  //     let userObj = {
  //       username: this.username,
  //       password: this.md5Password
  //     };
  //     //回调方法,一定要在接口调用直接创建
  //     window.loginCallback = this.onLoginCallback;
  //     //调用IOS 登录接口
  //     window.webkit.messageHandlers.login.postMessage(userObj);
  //   },
  //   /**
  //    * 处理登录接口返回值
  //    */
  //   onLoginCallback(result) {
  //     switch (result) {
  //       case "-1":
  //         alert("系统内部错误");
  //         break;
  //       case "0":
  //         //保存主动登录的用户名到 username
  //         this.$slots.commit('setUsername',this.username)
  //         this.onBackClick();
  //         break;
  //       case "1":
  //         alert("登录用户不存在");
  //         break;
  //       case "2":
  //         alert("用户密码错误");
  //         break;
  //     }
  //   },
  //   onToRegister() {
  //     /**
  //      *  立即注册点击事件
  //      */
  //     this.$router.push({
  //       name: "register",
  //       parmas: {
  //         routerType: "push"
  //       }
  //     });
  //   }
  }
};
</script>

<style lang="scss" scoped>
@import "@css/style";
.login-page {
  // 页面组件过渡动画,脱离标准文档流
  position: absolute;
  height: 100%;
  width: 100%;
  background-color: white;
  &-content {
    width: 100%;
    height: 100%;
    &-login {
      margin-top: 40%;
    }
    &-register {
      font-size: $infoSize;
      color: $textHintColor;
      margin-top: $marginSize;
      padding: $marginSize;
      float: right;
    }
  }
}
</style>