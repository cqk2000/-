<template>
  <div class="goods-list-page">
    <navigation-bar @onLeftClick="onBackCilck" :pageName="'商品列表'">
      <template v-slot:nav-right>
        <img :src="layoutType.icon" @click="onChangeLayoutTypeClick()" />
      </template>
    </navigation-bar>
    <!-- <div class="goods-list-page-content"> -->
    <div class="goods-list-page-content" :class="{'iphonex-bottom':$store.state.isIphoneX}">
      <!-- <p style="font-size:32px">goodsList</p> -->
      <goods-options @optionsChange="onGoodsOptionsChange"></goods-options>
      <goods :layoutType="layoutType.type" :sort="sortType"></goods>
    </div>
  </div>
</template>

<script>
import NavigationBar from "@c/currency/NavigationBar";
import GoodsOptions from "@c/goods/GoodsOptions";
import Goods from "@c/goods/Goods";

export default {
  name: "goodsList",
  components: {
    NavigationBar,
    GoodsOptions,
    Goods
  },
  data() {
    return {
      //goods 展示形式数据源
      layoutTypeDatas: [
        {
          //垂直列表
          type: "1",
          icon: require("@imgs/list-type.svg")
        },
        {
          //网格布局
          type: "2",
          icon: require("@imgs/grid-type.svg")
        },
        {
          //瀑布流布局
          type: "3",
          icon: require("@imgs/waterfall-type.svg")
        }
      ],
      //当前goods 展示形式
      layoutType: {},
      //goods 排序规则
      sortType: "1"
    };
  },
  created() {
    this.layoutType = this.layoutTypeDatas[0];
    // console.log(this.layoutType)
  },
  methods: {
    // 后退按钮点击事件
    onBackCilck() {
      this.$router.go(-1);
    },
    /**
     *  切换 goods 展示形式
     */
    onChangeLayoutTypeClick() {
      if (this.layoutType.type === "1") {
        this.layoutType = this.layoutTypeDatas[1];
      } else if (this.layoutType.type === "2") {
        this.layoutType = this.layoutTypeDatas[2];
      } else if (this.layoutType.type === "3") {
        this.layoutType = this.layoutTypeDatas[0];
      }
    },
    /**
     *  当筛选项改变时被调用
     */
    onGoodsOptionsChange(sortType) {
      this.sortType = sortType;
      //  console.log(this.sortType)
    }
  }
};
</script>
<style lang="scss" scoped>
@import "@css/style";
.goods-list-page {
  position: absolute;
  height: 100%;
  width: 100%;
  background: $bgColor;
  display: flex;
  flex-direction: column;
  position: absolute;
  &-content {
    height: 100%;
    display: flex;
    flex-direction: column;
  }
}
</style>