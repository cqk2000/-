<template>
  <!-- 在 vue这种单页面中的应用程序中,它只存在一个页面--App.vue,其他的都是组件 -->
  <div class="main">
    <!-- 动态组件 -->
    <component :is="currentComponent"></component>
    <tool-bar ref="toolBar" @onChangeFragment="onChangeFragment"></tool-bar>
  </div>
</template>
<script>
import toolBar from "@c/currency/ToolBar";
export default {
  name: "imooc",
  components: {
    "tool-bar": toolBar,
    //异步组件引入方式,异步组件:只要在需要去展示这个组件的时候,才会把组件去进行渲染
    home: () => import("@c/Home"),
    shopping: () => import("@c/Shopping"),
    my: () => import("@c/My")
  },
  data() {
    return {
      currentComponent: "home"
    };
  },
  activated() {
    //在 keepAlive 被激活的时候,调用指定加载页面组件的方法
    this.pushFragment();
  },
  methods: {
    //组件的切换
    onChangeFragment(componentName) {
      // console.log(componentName);
      this.currentComponent = componentName;
      // console.log(componentIndex)
    },
    /**
     * 指定加载的页面组件
     */
    pushFragment() {
      //获取掉组件加载的下标
      let componentIndex = this.$route.params.componentIndex;
      //如果 没有下标的话,直接让方法return掉
      if (componentIndex === undefined) return;
      //通过 toolbar 来切换对应的组件
      this.$refs.toolBar.pushFragment(componentIndex);
      //  console.log(99,componentIndex)
    }
  }
};
</script>
<style lang="scss" scoped>
.main {
  position: absolute;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}
</style>>