
/**
 * 判断当前设备是否为 IphoneX
 * @return boolean true 表示当前设备为 iphonex _ false  就不为 IphoneX
 */


const isIphoneX = () => {
    //window 对象存在执行逻辑
    if (typeof window !== 'undefined' && window) {
        // window.navigator.userAgent 如果他包含iphone 表示当前设备在IOS设备中运行
        //iphoneX 及以上的设备 屏幕垂直像素大于 812
        return /iphone/gi.test(window.navigator.userAgent) && window.screen.height >= 812
    }
    return false;
}


//计算结果 ,赋值给 window 对象的一个属性
window.isIphoneX = isIphoneX();