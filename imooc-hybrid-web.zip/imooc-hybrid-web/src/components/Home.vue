<template>
  <div class="home" @scroll="onScrollChenge" ref="home">
    <navigation-bar :isShowBack="false" :navBarStyle="navBarStyle">
      <!-- 左侧插槽 -->
      <template v-slot:nav-left>
        <!-- <img src="@imgs/more-white.svg" alt /> -->
        <img :src="navBarCurrentSlotStyle.leftIcon" alt />
      </template>
      <!-- 中间插槽 -->
      <template v-slot:nav-center>
        <!-- <p style="font-size:32px">中间插槽</p> -->
        <!-- <search :bgColor="'#ffffff'" :hintColor="'#99999'" :icon="require('@imgs/search.svg')"></search> -->
        <search
          :bgColor="navBarCurrentSlotStyle.search.bgColor"
          :hintColor="navBarCurrentSlotStyle.search.hintColor"
          :icon="navBarCurrentSlotStyle.search.icon"
        ></search>
      </template>
      <!-- 右侧插槽 -->
      <template v-slot:nav-right>
        <!-- <img src="@imgs/message-white.svg" alt /> -->
        <img :src="navBarCurrentSlotStyle.rightIcon" alt />
      </template>
    </navigation-bar>
    <div class="home-content">
      <!-- swiper -->
      <!-- <my-swiper :swiperImgs="swiperData.map(item=>item.icon)" :height="swiperHeight"></my-swiper> -->
      <my-swiper :swiperImgs="swiperImgs" :height="swiperHeight"></my-swiper>
      <!-- 520 活动 -->
      <activity>
        <div class="activity-520">
          <img v-for="(item,index) in activeitDatas" :key="index" :src="item.icon" />
        </div>
      </activity>
      <!-- 功能选项 -->
      <mode-options></mode-options>
      <!-- 秒杀模块 -->
      <seconds :dataSource="dataSource"></seconds>
      <!-- 拼购节 -->
      <activity>
        <div class="activity-pin-gou-jie">
          <img src="@imgs/haoHuoQiang.gif" alt />
        </div>
      </activity>
      <!-- 商品列表 -->
      <goods :layoutType="'3'" :isScroll="false"></goods>
    </div>
  </div>
</template>
<script>
import NavigationBar from "@c/currency/NavigationBar";
import MySwiper from "@c/swiper/MySwiper";
import Activity from "@c/currency/Activity";
import ModeOptions from "@c/currency/ModeOptions";
import Seconds from "@c/seconds/Seconds";
import Goods from "@c/goods/Goods";
import Search from "@c/currency/Search";
export default {
  components: {
    MySwiper,
    Activity,
    ModeOptions,
    Seconds,
    Goods,
    NavigationBar,
    Search
  },
  data() {
    return {
      swiperImgs: [
        require("@imgs/swiper-1.jpg"),
        require("@imgs/swiper-2.jpg"),
        require("@imgs/swiper-3.jpg"),
        require("@imgs/swiper-4.jpg"),
        require("@imgs/swiper-5.jpg"),
        require("@imgs/swiper-6.jpg"),
        require("@imgs/swiper-7.jpg"),
        require("@imgs/swiper-8.jpg")
      ],
      swiperData: [],
      activeitDatas: [],
      secondsDatas: [],
      swiperHeight:this.$store.state.isIphoneX ? '228px':'184px',
      dataSource: [
        {
          icon: require("@imgs/jingDongMiaoSha-1.jpg"),
          price: 119,
          oldprice: 169
        },
        {
          icon: require("@imgs/jingDongMiaoSha-2.jpg"),
          price: 1191,
          oldprice: 1900
        },
        {
          icon: require("@imgs/jingDongMiaoSha-3.jpg"),
          price: 199,
          oldprice: 289
        },
        {
          icon: require("@imgs/jingDongMiaoSha-4.jpg"),
          price: 55,
          oldprice: 78
        },
        {
          icon: require("@imgs/jingDongMiaoSha-5.jpg"),
          price: 19,
          oldprice: 30
        },
        {
          icon: require("@imgs/jingDongMiaoSha-6.jpg"),
          price: 56,
          oldprice: 76
        },
        {
          icon: require("@imgs/jingDongMiaoSha-7.jpg"),
          price: 99,
          oldprice: 200
        },
        {
          icon: require("@imgs/jingDongMiaoSha-8.jpg"),
          price: 36,
          oldprice: 176
        },
        {
          icon: require("@imgs/jingDongMiaoSha-9.jpg"),
          price: 96,
          oldprice: 99
        },
        {
          icon: require("@imgs/jingDongMiaoSha-10.jpg"),
          price: 86,
          oldprice: 109
        }
      ],
      activeitDatas: [
        { icon: require("@imgs/520-1.gif") },
        { icon: require("@imgs/520-2.gif") },
        { icon: require("@imgs/520-3.gif") }
      ],
      //navBar 插槽的样式数据,包含页面未开始滑动的时候插槽的样式 (默认的样式)
      // 和 页面滑动到锚定点之后的插槽的样式 (高亮样式,锚定点滑动的地点)
      navBarSlotStyle: {
        //默认样式
        normal: {
          //左侧插槽
          leftIcon: require("@imgs/more-white.svg"),
          search: {
            //中间插槽
            bgColor: "#ffffff",
            hintColor: "#999999",
            icon: require("@imgs/search.svg")
          },
          //右侧插槽
          rightIcon: require("@imgs/message-white.svg")
        },
        //高亮样式
        highlight: {
          //左侧插槽
          leftIcon: require("@imgs/more.svg"),
          search: {
            //中间插槽
            bgColor: "#d7d7d7",
            hintColor: "#ffffff",
            icon: require("@imgs/search-white.svg")
          },
          //右侧插槽
          rightIcon: require("@imgs/message.svg")
        }
      },
      // navBar 当前使用的插槽样式
      navBarCurrentSlotStyle: {},
      //new Bar 的定制样式,
      navBarStyle: {
        backgroundColor: "",
        position: "fixed"
      },
      //记录页面滚动值
      scrollTopValue: -1,
      //锚点值
      ANCHOR_SCROLL_TOP: 160
    };
  },
  created() {
    this.navBarCurrentSlotStyle = this.navBarSlotStyle.normal;
    // console.log(this.navBarCurrentSlotStyle);
    this.initData();
  },
  //(keepAlive组件被激活的时候调用)
  //去为滑动模块指定
  activated: function() {
    this.$refs.home.scrollTop = this.scrollTopValue;
  },
  methods: {
    //获取数据
    initData: function() {
      // console.log(1);
      // this.$http=axios;
      // this.$http
      //   .get("/swiper")
      //   .then(data => {
      //     // console.log(data);
      //     //通过请求的数据赋值给变量中
      //     this.swiperImgs = data.list;
      //   })
      //   .catch(err => {
      //     console.log(err);
      //   });
      // //520活动数据
      // this.$http
      //   .get("/activeitDatas")
      //   .then(data => {
      //     // console.log(data);
      //     //通过请求的数据赋值给变量中
      //     this.activeitDatas = data.list;
      //   })
      //   .catch(err => {
      //     console.log(err);
      //   });
      //axios 同时发送多个请求(并行)
      // this.$http
      //   .all([
      //     this.$http.get("/swiper"),
      //     this.$http.get("/activitys"),
      //     this.$http.get("/seconds")
      //   ])
      //   .then(
      //     this.$http.spread((swiperData, activityDatas, secondsDatas) => {
      //       this.swiperImgs = data.list;
      //       this.activeitDatas = data.list;
      //       this.secondsDatas = data.list;
      //     })
      //   );
    },
    /**
     *   监听页面
     *  1.获取到当前页面滚动的距离
     *  2.计算 navBar 背景颜色(navBar 背景透明度)
     *    当前滚动的距离 / 锚点值 = navBar 背景透明度 opacity
     *  3. opacity > 1 , 当前滚动的距离 已经等于或者超过了锚点值 , 当前navBar 插槽的样式变为高亮的样式
     * 否则的话 opacity < 1, 当前 navBar 插槽的样式,为默认状态的样式
     **/
    onScrollChenge: function($event) {
      //获取到当前页面滚动的距离
      this.scrollTopValue = $event.target.scrollTop;
      //计算 navBar 背景颜色(navBar 背景透明度)
      let opacity = this.scrollTopValue / this.ANCHOR_SCROLL_TOP;
      //根据透明比例来设置navBar的背景颜色
      // this.navBarSlotStyle.backgroundColor =
      //   "rgba(255,255,255," + opacity + ")";
      // console.log(2)
      // console.log(11111,this.navBarSlotStyle.highlight)
      this.navBarStyle.backgroundColor = "rgba(255, 255, 255, " + opacity + ")";
      //指定narBar 插槽样式
      if (opacity >= 1) {
        this.navBarCurrentSlotStyle = this.navBarSlotStyle.highlight;
      } else {
        this.navBarCurrentSlotStyle = this.navBarSlotStyle.normal;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
@import "@css/style.scss";
.home {
  width: 100%;
  height: 100%;
  background: $bgColor;
  overflow: hidden;
  overflow-y: auto;
  &-content {
    height: 100%;
    // border: 1px solid red;
    .activity-520 {
      margin-top: px2rem(-8);
      border-top-left-radius: px2rem(8);
      border-top-right-radius: px2rem(8);
      img {
        display: inline-block;
        width: 33.33%;
      }
    }
    .activity-pin-gou-jie {
      background: white;
      margin-top: $marginSize;
      img {
        width: 100%;
      }
    }
  }
}
</style>