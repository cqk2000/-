<template>
  <!--     
            如何在同一个组件中去展示不同的样式:
            1、html 表示整个布局的结构,具体展示样式,将有 css决定。
            2.每种展示样式对应不同的css ,也就是对应不同的类名 (css)
                    1.垂直列表 -> goods-list
                    2.网络布局 -> goods-grid
                    3.瀑布流布局 -> goods-waterfall
            3.实现不同的展示形式,本质上就是实现 不同的css 样式。
            瀑布流的布局:
            1、创建商品列表的基本html 和css,让item 相对于goods(div) 
            2、生成不同高度的图片,撑起不同高度的item
            3、计算item的位置,来达到从上到下,从左往右的依次排列的目的

            如果不允许 goods 单独滑动,那么就不添加 goods-scrool类
  -->
  <!-- 商品排序
              1.排序之后的数据源,用来在html 中进行展示 (替换掉 dataSource)。
              2.定义排序规则。(可以直接使用 GoodsOptions 中间数据源 id)
              3.定义排序的方法,根据、排序规则来修改对应的排序。
  -->
  <!-- <div class="goods goods-waterfall" :style="{height:goodsViewHeight}"> -->
  <!-- <div class="goods" :class="layoutClass" :style="{height:goodsViewHeight}"> -->
  <div
    class="goods"
    :class="[layoutClass,{'goods-scroll': isScroll}]"
    :style="{height:goodsViewHeight}"
    ref="goods"
    @scroll="onScrollChange"
  >
    <!-- <div
      class="goods-item goods-waterfall-item"
      v-for="(item,index) in dataSource"
      :key="index"
      ref="goodsItem"
      :style="goodsItemStyles[index]"
    >-->
    <div
      class="goods-item"
      :class="layoutItemClass"
      v-for="(item,index) in sortGoodsData"
      :key="index"
      ref="goodsItem"
      :style="goodsItemStyles[index]"
      @click="onItemClick(item)"
    >
      <!-- 图片 -->
      <img class="goods-item-img" :src="item.img" :style="imgStyles[index]" />
      <!--desc->description(描述)-->
      <div class="goods-item-desc">
        <p
          class="goods-item-desc-name text-line-2"
          :class="{'goods-item-desc-name-hint': !item.isHave}"
        >
          <!-- 是否为直营 -->
          <direct v-if="item.isDirect" />
          <!-- 是否有库存 -->
          <no-have v-if="!item.isHave" />
          {{item.name}}
        </p>
        <div class="goods-item-desc-data">
          <p class="goods-item-desc-data-price">￥{{ item.price | priceValue}}</p>
          <p class="goods-item-desc-data-price-volume">销量:{{item.volume}}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Direct from "@c/goods/Direct";
import NoHave from "@c/goods/NoHave";

export default {
  components: {
    Direct,
    NoHave
  },
  props: {
    /**
     *  在父元素中指定的展示形式
     * 1:垂直列表
     * 2:网格布局
     * 3:瀑布流布局
     */
    layoutType: {
      type: String,
      default: "1"
    },
    /**
     *  是否允许 goods 单独滑动
     *  默认允许 goods 单独滑动
     */
    isScroll: {
      type: Boolean,
      default: true
    },
    /**
     * 排序规则(依赖 GoodsOptions 数据源的id)
     * 1:默认
     * 1-2:价格由高到低
     * 1-3:销量由高到底
     * 2:有货优先
     * 3:自营优先
     */
    sort: {
      type: String,
      default: "1"
    }
  },
  data() {
    return {
      //数据源
      dataSource: [
        {
          id: 1,
          detailImgs: [
            require("@imgs/goods/goods-detail-1-1.jpg"),
            require("@imgs/goods/goods-detail-1-2.jpg"),
            require("@imgs/goods/goods-detail-1-3.jpg"),
            require("@imgs/goods/goods-detail-1-4.jpg"),
            require("@imgs/goods/goods-detail-1-5.jpg"),
            require("@imgs/goods/goods-detail-1-6.jpg")
          ],
          img: require("@imgs/goods/goods-1.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-1-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-4.webp.jpg")
          ],
          isDirect: false,
          isHave: true,
          name: "[二手95新] 劳力士 日志行系列 奢饰品18k白金男手腕表",
          price: "38000",
          volume: "143"
        },
        {
          id: 2,
          detailImgs: [
            require("@imgs/goods/goods-detail-2-1.jpg"),
            require("@imgs/goods/goods-detail-2-2.jpg"),
            require("@imgs/goods/goods-detail-2-3.jpg"),
            require("@imgs/goods/goods-detail-2-4.jpg"),
            require("@imgs/goods/goods-detail-2-5.jpg"),
            require("@imgs/goods/goods-detail-2-6.jpg")
          ],
          img: require("@imgs/goods/goods-2.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-2-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-2-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-2-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-2-4.webp.jpg")
          ],
          isDirect: true,
          isHave: true,
          name: "    Apple iPhone X [A1655] 64GB 黑色 移动联通电信4G手机",
          price: "5999",
          volume: "7356"
        },
        {
          id: 3,
          detailImgs: [
            require("@imgs/goods/goods-detail-3-1.jpg"),
            require("@imgs/goods/goods-detail-3-2.jpg"),
            require("@imgs/goods/goods-detail-3-3.jpg"),
            require("@imgs/goods/goods-detail-3-4.jpg"),
            require("@imgs/goods/goods-detail-3-5.jpg"),
            require("@imgs/goods/goods-detail-3-6.jpg"),
            require("@imgs/goods/goods-detail-3-7.jpg"),
            require("@imgs/goods/goods-detail-3-8.jpg"),
            require("@imgs/goods/goods-detail-3-9.jpg")
          ],
          img: require("@imgs/goods/goods-3.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-3-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-3-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-3-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-3-4.webp.jpg")
          ],
          isDirect: true,
          isHave: true,
          name: "坚果 [imGo] G7 家庭投影仪 投影机 家用",
          price: "2698",
          volume: "4878"
        },
        {
          id: 4,
          detailImgs: [
            require("@imgs/goods/goods-detail-4-1.jpg"),
            require("@imgs/goods/goods-detail-4-2.jpg"),
            require("@imgs/goods/goods-detail-4-3.jpg"),
            require("@imgs/goods/goods-detail-4-4.jpg"),
            require("@imgs/goods/goods-detail-4-5.jpg"),
            require("@imgs/goods/goods-detail-4-6.jpg"),
            require("@imgs/goods/goods-detail-4-7.jpg"),
            require("@imgs/goods/goods-detail-4-8.jpg"),
            require("@imgs/goods/goods-detail-4-9.jpg")
          ],
          img: require("@imgs/goods/goods-4.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-4-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-4-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-4-3.webp.jpg")
          ],
          isDirect: false,
          isHave: true,
          name: "三只松鼠 坚果炒货 孕妇坚果每日坚果干果零食",
          price: "29.8",
          volume: "734"
        },
        {
          id: 5,
          detailImgs: [
            require("@imgs/goods/goods-detail-2-1.jpg"),
            require("@imgs/goods/goods-detail-2-2.jpg"),
            require("@imgs/goods/goods-detail-2-3.jpg"),
            require("@imgs/goods/goods-detail-2-4.jpg"),
            require("@imgs/goods/goods-detail-2-5.jpg"),
            require("@imgs/goods/goods-detail-2-6.jpg")
          ],
          img: require("@imgs/goods/goods-5.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-2-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-2-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-2-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-2-4.webp.jpg")
          ],
          isDirect: false,
          isHave: false,
          name: "劳力士 潜航者型系列 男士绿水鬼手表 自动机械 ",
          price: "96000",
          volume: "9983"
        },
        {
          id: 6,
          detailImgs: [
            require("@imgs/goods/goods-detail-6-1.jpg"),
            require("@imgs/goods/goods-detail-6-2.jpg"),
            require("@imgs/goods/goods-detail-6-3.jpg"),
            require("@imgs/goods/goods-detail-6-4.jpg"),
            require("@imgs/goods/goods-detail-6-5.jpg"),
            require("@imgs/goods/goods-detail-6-6.jpg")
          ],
          img: require("@imgs/goods/goods-6.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-6-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-6-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-6-3.webp.jpg")
          ],
          isDirect: false,
          isHave: true,
          name: "光明 纯牛奶 PURE MLK 250ml*16 礼盒装",
          price: "37.9",
          volume: "10234"
        },
        {
          id: 7,
          detailImgs: [
            require("@imgs/goods/goods-detail-2-1.jpg"),
            require("@imgs/goods/goods-detail-2-2.jpg"),
            require("@imgs/goods/goods-detail-2-3.jpg"),
            require("@imgs/goods/goods-detail-2-4.jpg"),
            require("@imgs/goods/goods-detail-2-5.jpg"),
            require("@imgs/goods/goods-detail-2-6.jpg")
          ],
          img: require("@imgs/goods/goods-7.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-2-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-2-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-2-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-2-4.webp.jpg")
          ],
          isDirect: false,
          isHave: true,
          name: "瑞士欧米豁(CMEGA)手表海马系列300米潜水表",
          price: "31599",
          volume: "243"
        },
        {
          id: 8,
          detailImgs: [
            require("@imgs/goods/goods-detail-8-1.jpg"),
            require("@imgs/goods/goods-detail-8-2.jpg"),
            require("@imgs/goods/goods-detail-8-3.jpg"),
            require("@imgs/goods/goods-detail-8-4.jpg"),
            require("@imgs/goods/goods-detail-8-5.jpg"),
            require("@imgs/goods/goods-detail-8-6.jpg"),
            require("@imgs/goods/goods-detail-8-7.jpg")
          ],
          img: require("@imgs/goods/goods-8.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-8-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-8-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-8-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-8-4.webp.jpg")
          ],
          isDirect: false,
          isHave: true,
          name: "简易迷你手动榨汁机儿童榨汁水果挤压汁机橙子",
          price: "10",
          volume: "6642"
        },
        {
          id: 9,
          detailImgs: [
            require("@imgs/goods/goods-detail-9-1.jpg"),
            require("@imgs/goods/goods-detail-9-2.jpg"),
            require("@imgs/goods/goods-detail-9-3.jpg"),
            require("@imgs/goods/goods-detail-9-4.jpg"),
            require("@imgs/goods/goods-detail-9-5.jpg"),
            require("@imgs/goods/goods-detail-9-6.jpg"),

            require("@imgs/goods/goods-detail-9-7.jpg"),
            require("@imgs/goods/goods-detail-9-8.jpg")
          ],
          img: require("@imgs/goods/goods-9.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-9-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-9-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-9-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-9-4.webp.jpg")
          ],
          isDirect: false,
          isHave: true,
          name: "迷彩 短袖T恤男2019新款衬衫打底衫潮流polo",
          price: "88",
          volume: "28362"
        },
        {
          id: 10,
          detailImgs: [
            require("@imgs/goods/goods-detail-1-1.jpg"),
            require("@imgs/goods/goods-detail-1-2.jpg"),
            require("@imgs/goods/goods-detail-1-3.jpg"),
            require("@imgs/goods/goods-detail-1-4.jpg"),
            require("@imgs/goods/goods-detail-1-5.jpg"),
            require("@imgs/goods/goods-detail-1-6.jpg")
          ],
          img: require("@imgs/goods/goods-10.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-1-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-4.webp.jpg")
          ],
          isDirect: false,
          isHave: true,
          name: "伊利 安慕希希腊风味常温酸奶原味250g*16盒",
          price: "59.9",
          volume: "7654"
        },
        {
          id: 11,
          detailImgs: [
            require("@imgs/goods/goods-detail-1-1.jpg"),
            require("@imgs/goods/goods-detail-1-2.jpg"),
            require("@imgs/goods/goods-detail-1-3.jpg"),
            require("@imgs/goods/goods-detail-1-4.jpg"),
            require("@imgs/goods/goods-detail-1-5.jpg"),
            require("@imgs/goods/goods-detail-1-6.jpg")
          ],
          img: require("@imgs/goods/goods-11.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-1-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-4.webp.jpg")
          ],
          isDirect: false,
          isHave: true,
          name: "[二手95新] 劳力士 日志行系列 奢饰品18k白金男手腕表",
          price: "38000",
          volume: "143"
        },
        {
          id: 12,
          detailImgs: [
            require("@imgs/goods/goods-detail-1-1.jpg"),
            require("@imgs/goods/goods-detail-1-2.jpg"),
            require("@imgs/goods/goods-detail-1-3.jpg"),
            require("@imgs/goods/goods-detail-1-4.jpg"),
            require("@imgs/goods/goods-detail-1-5.jpg"),
            require("@imgs/goods/goods-detail-1-6.jpg")
          ],
          img: require("@imgs/goods/goods-12.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-1-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-4.webp.jpg")
          ],
          isDirect: false,
          isHave: true,
          name: "[二手95新] 劳力士 日志行系列 奢饰品18k白金男手腕表",
          price: "38000",
          volume: "143"
        },
        {
          id: 13,
          detailImgs: [
            require("@imgs/goods/goods-detail-13-1.jpg"),
            require("@imgs/goods/goods-detail-13-2.jpg"),
            require("@imgs/goods/goods-detail-13-3.jpg"),
            require("@imgs/goods/goods-detail-13-4.jpg"),
            require("@imgs/goods/goods-detail-13-5.jpg"),
            require("@imgs/goods/goods-detail-13-6.jpg")
          ],
          img: require("@imgs/goods/goods-13.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-13-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-13-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-13-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-13-4.webp.jpg")
          ],
          isDirect: false,
          isHave: true,
          name: "[二手95新] 劳力士 日志行系列 奢饰品18k白金男手腕表",
          price: "38000",
          volume: "143"
        },
        {
          id: 14,
          detailImgs: [
            require("@imgs/goods/goods-detail-1-1.jpg"),
            require("@imgs/goods/goods-detail-1-2.jpg"),
            require("@imgs/goods/goods-detail-1-3.jpg"),
            require("@imgs/goods/goods-detail-1-4.jpg"),
            require("@imgs/goods/goods-detail-1-5.jpg"),
            require("@imgs/goods/goods-detail-1-6.jpg")
          ],
          img: require("@imgs/goods/goods-14.jpg"),
          swiperImgs: [
            require("@imgs/goods/goods-swiper-1-1.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-2.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-3.webp.jpg"),
            require("@imgs/goods/goods-swiper-1-4.webp.jpg")
          ],
          isDirect: false,
          isHave: true,
          name: "[二手95新] 劳力士 日志行系列 奢饰品18k白金男手腕表",
          price: "38000",
          volume: "143"
        }
      ],
      //排序数据
      sortGoodsData: [],
      //最大高度
      MAX_IMG_HEIGHT: 230,
      //最小高度
      MIN_IMG_HEIGHT: 178,
      //图片样式集合
      imgStyles: [],
      //item margin
      ITEM_MARGIN_SIZE: 8,
      // item样式集合
      goodsItemStyles: [],
      // goodsViewHeight  goods 组件的高度
      // goodsViewHeight: 0,
      goodsViewHeight: "100%",
      //不同展示形式下的类名
      // 1.垂直列表的展示形式 (默认) -> goods-list & goods-list-item
      //2.网格布局的展示样式 -> goodsgrid & goods-grid-item
      layoutClass: "goods-list",
      layoutItemClass: "goods-list-item",
      //滑动距离
      scrollTopValue: 0
    };
  },
  created() {
    this.initData();
    // this.initImgStyle();
    // //调用创建瀑布流的方法(等到 dom 创建完成之后)
    // this.$nextTick(() => {
    //   this.initWaterfall();
    // });
    //设置布局
    //       this.$nextTick(() => {
    //   this.initLayout();
    //  });
    // this.initLayout();
    // console.log(65)
  },
  activated() {
    // 定位页面滑动的位置
    this.$refs.goods.scrollTop = this.scrollTopValue;
    //  console.log(this.scrollTopValue)
  },
  methods: {
    // 获取数据
    initData() {
      // //   this.$http.get("/goods").then(data => {
      // //     console.log(data.list);
      // //     this.dataSource = data.list;
      // //   });
      //数据的排序
      this.setSortGoodsData();
      //设置布局
      this.initLayout();
      // console.log(this.sortGoodsData)
      // },
      /**
       * 返回随机的图片
       */
    },
    /**
     * 商品排序
     */
    setSortGoodsData() {
      // console.log(4864684,this.sort)
      switch (this.sort) {
        // 默认
        case "1":
          // 深拷贝，不改变原数组
          this.sortGoodsData = this.dataSource.slice(0);
          break;
        // 价格
        case "1-2":
          this.getSortGoodsDataFromKey("price");
          break;
        // 销量
        case "1-3":
          this.getSortGoodsDataFromKey("volume");
          break;
        // 有货优先
        case "2":
          this.getSortGoodsDataFromKey("isHave");
          break;
        // 直营优先
        case "3":
          this.getSortGoodsDataFromKey("isDirect");
          break;
      }
    },
    /**
     * 根据传入的key 来进行排序
     */
    getSortGoodsDataFromKey(key) {
      /**
       * sort 可以完成数组的数据排序。
       * 当前接收的值 为负数的时候 表示 goods1 排列 goods2 之前
       * 当接收的值为正数的时候,表示goods1 排列在goods2之后
       * 接收的值为  0 的时候,表示排序不变。
       */
      return this.sortGoodsData.sort((goods1, goods2) => {
        //根据传入的key获取对应的value
        let v1 = goods1[key],
          v2 = goods2[key];
        // 对value 进行对比
        //boolean 类型的值 (有货优先和直营优先)
        if (typeof v1 === "boolean") {
          if (v1) {
            return -1;
          }
          if (v2) {
            return 1;
          }
          return 0;
        }
        //float 类型的值处理(价格、销量)
        if (parseFloat(v1) >= parseFloat(v2)) {
          return -1;
        }
        return 1;
      });
    },
    imgHeight: function() {
      // Math.random() ->0-1 随机数 *(高度区间) + 最低的图片高度
      let result = Math.floor(
        Math.random() * (this.MAX_IMG_HEIGHT - this.MIN_IMG_HEIGHT) +
          this.MIN_IMG_HEIGHT
      );
      return result;
    },
    /**
     *  根据随机的图片高度,生成对应的图片数据
     */
    initImgStyle() {
      this.dataSource.forEach(item => {
        //随机生成的图片高度
        let imgHeight = this.imgHeight() + "px";
        //push 图片高度,到img 样式集合
        this.imgStyles.push({
          height: imgHeight
        });
      });
    },
    /**
     *  瀑布流布局
     * 1.获取到所有的 item 元素
     * 2.遍历 item 元素,得到每一个 item的高度,加上一个 margin 的高度
     * 3.创建两个变量:leftHeightTotal,rightHeightTotal 分别表示左右两侧的距离顶部的高度
     * 通过对于左右两侧距离顶部的高度,来确定 item 的放置位置。
     *        如果左侧小于等于右侧高度的话 (leftHeightTotal <=rightHeightTotal),那么
     *        item就应该放置到左侧。此时 item 距离左侧为0 ,距离顶部为当前的leftHeightTotal
     *        否则,item 放置到右侧,此时item距离右侧为0,距离顶部为当前的rightHeightTotal。
     * 4.保存计算出的 item 的所有样式,配置到item 上.
     * 5.item 配置 完成之后,对比左右两侧最大的高度,最大的高度为 goods 组件的高度
     */
    initWaterfall() {
      //获取所有的item元素
      // console.log(1);
      let $goodsItems = this.$refs.goodsItem;
      if (!$goodsItems) return;
      //左右两侧距离顶部的高度
      let leftHeightTotal = 0,
        rightHeightTotal = 0;
      // 2.遍历 item 元素,得到每一个 item的高度,加上一个 margin 的高度
      $goodsItems.forEach(($el, index) => {
        //item 样式
        let goodsItemStyle = {};
        let elHeight = $el.clientHeight + this.ITEM_MARGIN_SIZE;
        //对比 左右 两侧距离顶部的高度
        if (leftHeightTotal <= rightHeightTotal) {
          // item就应该放置到左侧。此时 item 距离左侧为0 ,距离顶部为当前的leftHeightTotal
          goodsItemStyle = {
            left: "0px",
            top: leftHeightTotal + "px"
          };
          //更新左侧距离顶部的高度
          leftHeightTotal += elHeight;
        } else {
          //item 距离 右侧 为0 距离顶部为当前的rightHeightTotal。
          goodsItemStyle = {
            right: "0px",
            top: rightHeightTotal + "px"
          };
          //更新右侧距离顶部的高度
          rightHeightTotal += elHeight;
        }
        // 保存计算出的 item 的所有样式,配置到item 上.
        this.goodsItemStyles.push(goodsItemStyle);
      });
      //对比左右两侧最大高度,最大高度为 goods组件的高度
      //在不允许 Goods 单独滑动的时候
      if (!this.isScroll) {
        //对比左右两侧最大高度,最大高度为 goods组件的高度
        this.goodsViewHeight =
          (leftHeightTotal > rightHeightTotal
            ? leftHeightTotal
            : rightHeightTotal) + "px";
      }
      //5.item 配置 完成之后,对比左右两侧最大的高度,最大的高度为 goods 组件的高度
    },

    /**
     *  设置布局,为不同的layoutType 设置不同的展示形式
     * 1.初始化影响到布局的数据
     *    1.goodsViewHeight -> 垂直布局、网格布局 (100%)  、瀑布流 (实际高度)
     *    2.goodsItemStyle
     *    3.imgStyles
     *    2.为不同的 layoutType 设置不同的展示类
     */
    initLayout() {
      // console.log(5446454);
      //初始化数据
      this.goodsViewHeight = "100%";
      this.goodsItemStyles = [];
      this.imgStyles = [];
      // console.log(51564);
      // console.log(this.layoutType);
      switch (this.layoutType) {
        //垂直列表
        case "1":
          (this.layoutClass = "goods-list"),
            (this.layoutItemClass = "goods-list-item");
          break;
        //网格布局
        case "2":
          (this.layoutClass = "goods-grid"),
            (this.layoutItemClass = "goods-grid-item");
          break;
        //瀑布流布局
        case "3":
          (this.layoutClass = "goods-waterfall"),
            (this.layoutItemClass = "goods-waterfall-item");
          this.initImgStyle();
          //调用创建瀑布流的方法(等到 dom 创建完成之后)
          this.$nextTick(() => {
            this.initWaterfall();
          });
          break;
      }
    },
    /**
     *  商品点击事件
     */
    onItemClick(item) {
      // 商品无库存不允许跳转
      if (!item.isHave) {
        alert("该商品无库存");
        return;
      }
      this.$router.push({
        name: "goodsDetail",
        params: {
          routerType: "push",
          goods: item
        }
      });
    },
    /**
     * 监听滑动事件
     */
    onScrollChange($event) {
      this.scrollTopValue = $event.target.scrollTop;
    }
  },
  watch: {
    /**
     *  监听 layoutType
     */
    layoutType: function() {
      // console.log(1);
      this.initLayout();
    },
    /**
     *  监听sort 的改变
     */
    sort() {
      this.setSortGoodsData();
      // console.log(22);
    }
  }
};
</script>

<style lang="scss" scoped>
@import "@css/style.scss";
.goods {
  background-color: $bgColor;
  // overflow: hidden;
  // overflow-y: auto;
  &-scroll {
    overflow: hidden;
    overflow-y: auto;
  }
  &-item {
    background-color: white;
    padding: $marginSize;
    box-sizing: border-box;
    &-desc {
      width: 100%;
      &-name {
        font-size: $infoSize;
        line-height: px2rem(18);
        &-hint {
          color: $textHintColor;
        }
      }
      &-data {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: $marginSize;
        &-price {
          font-size: $titleSize;
          color: $mainColor;
          font-weight: 500;
          &-volume {
            font-size: $infoSize;
            color: $textHintColor;
          }
        }
      }
    }
  }
}
//垂直列表
.goods-list {
  &-item {
    display: flex;
    border-bottom: 1px solid $lineColor;
    .goods-item-img {
      width: px2rem(120);
      height: px2rem(120);
    }
    .goods-item-desc {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      padding: $marginSize;
    }
  }
}
//网格布局
.goods-grid {
  padding: $marginSize;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  &-item {
    width: 49%;
    margin-bottom: $marginSize;
    .goods-item-img {
      width: 100%;
    }
  }
}
//瀑布流
.goods-waterfall {
  position: relative;
  margin: $marginSize;
  &-item {
    position: absolute;
    width: 49%;
    border-radius: $radiusSize;
    .goods-item-img {
      width: 100%;
    }
  }
}
</style>