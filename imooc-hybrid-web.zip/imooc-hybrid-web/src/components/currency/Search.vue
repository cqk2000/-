<template>
  <div class="search" :style="searchStyle">
    <img class="search-icon" :src="icon" alt />
    <span class="search-hint" :style="hintStyle">大前端开发,混合京东商城系统</span>
  </div>
</template>
<script>
export default {
  //图标
  props: {
    icon: {
      default: require("@imgs/search.svg"),
      type: String
    },
    //字体颜色
    hintColor: {
      default: "#999999",
      type: String
    },
    //背景颜色
    bgColor: {
      default: "#ffffff",
      type: String
    }
  },
  computed: {
    searchStyle: function() {
      return {
        backgroundColor: this.bgColor
      };
    },
    hintStyle: function() {
      return {
        color: this.hintColor
      };
    }
  },
  updated() {
    // console.log(this.searchStyle);
    // console.log(this.hintStyle);
  }
};
</script>

<style lang="scss" scoped>
@import "@css/style.scss";
.search {
  background: white;
  width: 100%;
  margin: px2rem(6);
  border-radius: px2rem(22);
  display: flex;
  align-items: center;

  &-icon {
    margin-left: $marginSize;
    width: px2rem(16);
  }
  &-hint {
    margin-left: $marginSize;
    font-size: $minInfoSize;
    color: $textHintColor;
  }
}
</style>