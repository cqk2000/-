<template>
  <div class="tool-bar" :class="{'iphonex-bottom': $store.state.isIphoneX}">
    <!-- tab 按钮 ,需要一个数据源,通过这个数据源来去驱动视图 -->
    <div
      class="tool-bar-item"
      v-for="(item,index) in toolBarData"
      :key="index"
      @click="onChangeFragment(item,index)"
    >
      <!-- 当当前 img 标签的index ===选中tab的index 的时候,就让img 显示高亮图片 -->
      <img
        class="tool-bar-item-img"
        v-bind:src="[index===selectItemIndex ? item.hIcon : item.nIcon]"
        alt
      />
      <!-- 当当前 p标签的index ===选中tab的index 的时候,就让p  添加高亮状态的类 -->
      <p
        class="tool-bar-item-name"
        :class="{'tool-bar-item-name-h' : index===selectItemIndex}"
      >{{item.name}}</p>
    </div>
  </div>
</template>

<script>
// ToolBar 的功能:
//  1:永远位于页面的最底部
//  2:点击Toolbar 按钮的时候,页面发生对应的切换
//  3:按钮分为默认 和选中 两个状态

// 功能和约束
// 1.不具备的能力 (约束)
// 2.通过一个回调,告诉父组件,按钮的点击事件
// 3.当按钮被选中的时候,应该切换按钮的状态

export default {
  data() {
    return {
      //tab按钮数据源,vue、react、angular、MVVM框架,数据驱动视图
      toolBarData: [
        {
          //默认状态下的图片
          nIcon: require("@imgs/home-n.svg"),
          //高亮状态的图片
          hIcon: require("@imgs/home-h.svg"),
          //名称
          name: "首页",
          //要跳转的组件名称
          componentName: "home"
        },
        {
          //默认状态下的图片
          nIcon: require("@imgs/shopping-n.svg"),
          //高亮状态的图片
          hIcon: require("@imgs/shopping-h.svg"),
          //名称
          name: "购物车",
          //要跳转的组件名称
          componentName: "shopping"
        },
        {
          //默认状态下的图片
          nIcon: require("@imgs/my-n.svg"),
          //高亮状态的图片
          hIcon: require("@imgs/my-h.svg"),
          //名称
          name: "我的",
          //要跳转的组件名称
          componentName: "my"
        }
      ],
      //选中的tab按钮
      selectItemIndex: 0
    };
  },
  methods: {
    onChangeFragment(item, index) {
      this.selectItemIndex = index;
      //向父组件传递一个事件
      this.$emit("onChangeFragment", item.componentName);
    },
    // 指定切换的tab页
    pushFragment(index) {
      //调用onChangeFragment 切换对应的 tab
      this.onChangeFragment(this.toolBarData[index], index);
    }
  }
};
</script>

<style lang="scss" scoped>
@import "@css/style.scss";
.tool-bar {
  width: 100%;
  height: px2rem(46);
  display: flex;
  justify-content: space-around;
  background-color: white;
  box-shadow: 0 0 16px 0 rgba(0, 0, 0, 0.2);
  border-top: 1px solid $lineColor;
  &-item {
    text-align: center;
    padding: px2rem(4) px2rem(12);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    &-img {
      width: px2rem(22);
      height: px2rem(22);
    }
    &-name {
      font-size: $infoSize;
      margin-top: px2rem(4);

      &-h {
        color: $mainColor;
      }
    }
  }
}
</style>