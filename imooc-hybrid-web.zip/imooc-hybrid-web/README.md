# imooc-hybrid-web

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

### 轮播图组件

npm install swiper vue-awesome-swiper --save

easy-mock.com


### 安装 axios 

npm install axios

